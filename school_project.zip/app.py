from flask import render_template, Flask, request
from bs4 import BeautifulSoup
import requests

app = Flask(__name__)

@app.route("/", methods=["GET", "POST"])
def index():
    return render_template("index.html")


@app.route("/musics/", methods=["GET", "POST"])
def musics_items():
    
    url = "https://soundcloud.com"
    r0 = requests.get(url=url)
    
    if r0.status_code != 200:
        pass
    
    hc = open("f0.html")
    ht = hc.read()
    
    hc.close()
    
    byte_text = bytes(ht, encoding="utf8")
    soup = BeautifulSoup(byte_text, "html.parser")
    
    images, artitst, playlists = [], [], []
    
    # image scraping
    s2 = "playableTile__image"
    res2 = soup.find_all("div", class_=s2)
    all_stytles = []

    for item in res2:
        all_stytles.append(item.span['style'])
    
    for item in all_stytles:
        images.append(
            item.split("url(")[1].split(")")[0].strip('"')
        )
    
    
    # artist names scraping
    artist_name = []
    res3 = soup.find_all("div", class_="playableTile__descriptionContainer")

    for item in res3:
        artist_name.append(
            item.a.text
        )

    for name in artist_name:
        artitst.append(
            name.strip().replace(" ", "").replace("\n", " ")
        )

    # playlist scraping
    selector="sc-link-primary sc-link-dark sc-type-light sc-text-secondary playableTile__mainHeading playableTile__heading audibleTile__audibleHeading sc-truncate sc-font-light sc-text-h4"

    res5 = soup.find_all("a", {"class": selector})
    for item in res5:
        playlists.append(item['href'])
    
    length = len(playlists)

    data = {
        "artist_name": artitst,
        "image_urls": images,
        "playlist": playlists,
        "length": length,
    }
        
    return render_template("musics.html", data=data)



@app.route("/movies", methods=["GET", "POST"])
def movies():
    
    category = ""
    data = {}
    if request.method == "POST":
        if request.form["movie_name"] == "":
            category = "Comedy"
        
        category = request.form["movie_name"]
                
        r0 = requests.get("https://www.imdb.com/feature/genre/")
        
        if r0.status_code != 200:
            pass
        
        soup = BeautifulSoup(r0.content, "html.parser")
        selector ="image"
        res0 = soup.find_all("div", {"class": selector})

        hyperlinks, titles = [], []

        for item in res0:
            hyperlinks.append(item.a['href'])
            titles.append(item.a.img['title'])
        
        category = category.title()
        if category not in titles:
            category = "Comedy"
        
        category_url = hyperlinks[titles.index(category)]
        movie_names, year_release, rating = scraper(category_url)
        
        length = len(movie_names)
        
        data = {
            "movie": movie_names,
            "year_release": year_release,
            "rating": rating,
            "length": length,
        }        
    
    return render_template("movies.html", data=data)


@app.route('/news', methods=["GET", "POST"])
def news():
        
    url = 'https://www.businesstoday.in/technology/news'

    r0 = requests.get(url=url)

    soup = BeautifulSoup(r0.content, "html.parser")

    headlines = []
    headline_soup = soup.find_all('div', {"class": "widget-listing"}, limit=20)
    img_links = []

    desc = []

    for idx in headline_soup:
        headlines.append(idx.div.div.a['title'])
        desc.append(idx.find('p').text)
        img_links.append(idx.div.a.img['data-src'])

    datetime = []
    dt_soup = soup.find_all("div", {"class": "widget-listing-content-section"}, limit=20)
    hyperlinks = []

    for dt in dt_soup:
        res = dt.span.text.split(":")
        datetime.append(res[-1])
        hyperlinks.append(dt.h2.a['href'])
    
    data = {
        "headlines": headlines,
        "description": desc,
        "timestamp": datetime,
        "hyperlinks": hyperlinks,
        "image": img_links,
        "length": 20
    }

        
    return render_template("news.html", data=data)



def scraper( bu):
    
    tr = requests.get(bu)
    if tr.status_code != 200:
        return []
    
    ts = BeautifulSoup(tr.content, "html.parser")
        
    selector = "lister-item-content"
    tres = ts.find_all("div", {"class": selector})    
    
    ms_, yr_, rt_ = [], [], []
        
    for item in tres:
        ms_.append(item.a.string)
    
    tres2 = ts.find_all("div", class_="ratings-bar")
    for item in tres2:
        rt_.append(item.strong.string)
    
            
    selector = "lister-item-year text-muted unbold"
    tres3 = ts.find_all("span", class_=selector)

    for item in tres3:
        yr_.append(item.string)

    return (ms_, yr_, rt_ )   
